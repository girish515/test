import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { LoginComponent } from './login/login.component';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {MatTableModule} from '@angular/material/table';
import { EmployerdetailsComponent } from './maintenance/employerdetails/employerdetails.component';
import { NotificationsComponent } from './maintenance/notifications/notifications.component';
import { SubscriptionpaygroupComponent } from './maintenance/subscriptionpaygroup/subscriptionpaygroup.component';
import { CommenthistoryComponent } from './maintenance/commenthistory/commenthistory.component';
import { MyInterceptor } from './myinterceptor';
import { MatDialogModule } from '@angular/material/dialog';
import { EmployercommonpopupComponent } from './maintenance/employerdetails/employercommonpopup/employercommonpopup.component';
import { EmployerresetpopupComponent } from './maintenance/employerdetails/employerresetpopup/employerresetpopup.component';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import {MatExpansionModule} from '@angular/material/expansion';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    MaintenanceComponent,
    LoginComponent,
    EmployerdetailsComponent,
    NotificationsComponent,
    SubscriptionpaygroupComponent,
    CommenthistoryComponent,
    EmployercommonpopupComponent,
    EmployerresetpopupComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule,
    NoopAnimationsModule,
    MatTableModule,
    MatDialogModule,
    MatSelectModule,
    MatPaginatorModule,
    MatSortModule,
    MatExpansionModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS, useClass: MyInterceptor, multi: true
    }
    

  ],
  bootstrap: [AppComponent],
 
})
export class AppModule { }
