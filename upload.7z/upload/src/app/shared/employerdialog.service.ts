import { Injectable } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { EmployercommonpopupComponent } from '../maintenance/employerdetails/employercommonpopup/employercommonpopup.component';
import { EmployerresetpopupComponent } from '../maintenance/employerdetails/employerresetpopup/employerresetpopup.component';


@Injectable({
  providedIn: 'root'
})
export class EmployerdialogService {
 
  constructor(private dialog: MatDialog) { }

  openDialog(msg:any){
    console.log("inside openPostErCodeToADPDialog")
    console.log("inside openCancelSubDialog")
    return this.dialog.open(EmployercommonpopupComponent,{
      width: '390px',
      data:{
        message:msg
      }
    });
  }

  openResetDialog() {
    console.log("inside openResetDialog")
    const dialogConfig = new MatDialogConfig
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus= true;
    dialogConfig.width = '390px';
    return this.dialog.open(EmployerresetpopupComponent,dialogConfig);
  }

}
