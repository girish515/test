import { TestBed } from '@angular/core/testing';

import { EmployerdialogService } from './employerdialog.service';

describe('EmployerdialogService', () => {
  let service: EmployerdialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployerdialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
