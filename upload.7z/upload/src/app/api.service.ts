import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private httpClient: HttpClient) { }

  getCommentsByCommentId(){
     return this.httpClient.get("http://localhost:8080/api/config/comment/"+10);
  }

  postComments(){
    let body = { 
        commentData :'TestComment',
        user : 'admin'
    }
    return this.httpClient.post("http://localhost:8080/api/config/comment",body)
  }

  callHome(){
      console.log("callhome invocked in app");
      let headers = new HttpHeaders();
      headers.set("Access-Control-Allow-Origin" ,'*');
      headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
       // Request headers you wish to allow
  headers.set('Access-Control-Allow-Headers', 'X-Requested-With, content-type, token, language');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  headers.set('Access-Control-Allow-Credentials', "true");

    return this.httpClient.get("http://localhost:8080/api/home", {headers});

//      return this.httpClient.get("https://fedssoqa.equifax.com/as/authorization.oauth2?response_type=code&client_id=ews-epic-connector-nonprod&scope=openid%20profile%20groups&redirect_uri=http://localhost:8080/authentication/oauth&state=/api/home");
//      return this.httpClient.get("https://fedssoqa.equifax.com/as/authorization.oauth2?response_type=code&client_id=ews-epic-connector-nonprod&scope=openid%20profile%20groups&redirect_uri=http://localhost:8080/authentication/oauth&state=/maintenance");
    }

}