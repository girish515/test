import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from './api.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'equifax';
  isLogin = false;
  currentUser: any;
  constructor( private activatedRoute:ActivatedRoute,
    private router: Router, private apiService:ApiService
) {
}

ngOnInit(): void {
/*  this.activatedRoute.queryParams.subscribe(params => {
    let isLogin = params['login'];
    if(isLogin === true || localStorage.getItem('login') === 'true'){
      this.isLogin = true;
      localStorage.setItem('login','true');
    } else {

    }
  }); */
 console.log("callHome invocked");
  this.apiService.callHome().subscribe( (data) =>{
    console.log("");
  }); 
}

logout(e:any) {
this.isLogin = e;
localStorage.setItem('login','false');
}

}
