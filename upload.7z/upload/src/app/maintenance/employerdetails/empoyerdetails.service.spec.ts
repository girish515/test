import { TestBed } from '@angular/core/testing';

import { EmpoyerdetailsService } from './empoyerdetails.service';

describe('EmpoyerdetailsService', () => {
  let service: EmpoyerdetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmpoyerdetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
