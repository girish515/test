import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class EmpoyerdetailsService {
 

  constructor(private httpClient: HttpClient) { }

  getEmployerDetails(searchId : string ): Observable<any>{
    let url = 'http://localhost:8090//employers-api/v1/'+searchId
    return this.httpClient.get(url);
  }
  updateEmployeeDetails(employerDetails: any) : Observable<any> {
   console.log("updateEmployeeDetails -- > Pilot "  + employerDetails.clientDetails[0].isPilot)
   let url = 'http://localhost:8090/employers-api/v1/onboard'
   return this.httpClient.post(url,JSON.stringify(employerDetails));
  }

  updateScheduleDetails(refreshApiRequest: any): Observable<any>{
    let url = 'http://localhost:8094/scheduler-api/v1/refresh'
    return this.httpClient.post(url,JSON.stringify(refreshApiRequest));
  }
}
