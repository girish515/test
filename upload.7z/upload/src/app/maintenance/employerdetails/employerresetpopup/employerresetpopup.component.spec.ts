import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployerresetpopupComponent } from './employerresetpopup.component';

describe('EmployerresetpopupComponent', () => {
  let component: EmployerresetpopupComponent;
  let fixture: ComponentFixture<EmployerresetpopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployerresetpopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployerresetpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
