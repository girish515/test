import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {MatSelectModule} from '@angular/material/select';

@Component({
  selector: 'app-employerresetpopup',
  templateUrl: './employerresetpopup.component.html',
  styleUrls: ['./employerresetpopup.component.css']
})
export class EmployerresetpopupComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
  public dialogRef: MatDialogRef<EmployerresetpopupComponent>) { }
  selectedValue: any
  ngOnInit(): void {
  }

}
