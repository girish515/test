import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployercommonpopupComponent } from './employercommonpopup.component';

describe('EmployercommonpopupComponent', () => {
  let component: EmployercommonpopupComponent;
  let fixture: ComponentFixture<EmployercommonpopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployercommonpopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployercommonpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
