import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-employercommonpopup',
  templateUrl: './employercommonpopup.component.html',
  styleUrls: ['./employercommonpopup.component.css']
})
export class EmployercommonpopupComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
  public dialogRef: MatDialogRef<EmployercommonpopupComponent>) { }

  ngOnInit(): void {
  }

}
