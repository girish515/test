import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { EmployerdialogService } from 'src/app/shared/employerdialog.service';
import { EmpoyerdetailsService } from './empoyerdetails.service';

@Component({
  selector: 'app-employerdetails',
  templateUrl: './employerdetails.component.html',
  styleUrls: ['./employerdetails.component.css']
})
export class EmployerdetailsComponent implements OnInit {

  @Input() clientId: any;
  @Input() employerCode: any;
  employerDetails: any = {};
  refreshApiRequest: any ={};

  constructor(private empoyerdetailsService: EmpoyerdetailsService ,
      private employerdialogService: EmployerdialogService) { 
      
      }

  ngOnInit(): void {
    this.getNoEmployerDetails();
  }

  getNoEmployerDetails() {
    if (this.clientId) {
        this.empoyerdetailsService.getEmployerDetails(this.clientId).subscribe((data: any) => {
        this.employerDetails = data;
      });
    } else if (this.employerCode) {
      this.empoyerdetailsService.getEmployerDetails(this.employerCode).subscribe((data: any) => {
       this.employerDetails = data;
      });
    }
  }

  onMarkAsPilot(msg:any){
    this.employerdialogService.openDialog(msg).afterClosed().subscribe(res=>{
      console.log(res)
      if(res){
        this.employerDetails.clientDetails[0].isPilot='Y';
        this.empoyerdetailsService.updateEmployeeDetails(this.employerDetails).subscribe((data: any) =>{
        this.employerDetails = data;
        });
      }
    });
  }

  cancelSubscription(msg:any){
    console.log("Inside cancel sub")
    this.employerdialogService.openDialog(msg).afterClosed().subscribe(res=>{
      console.log(res)
      if(res){
        this.employerDetails.clientDetails[0].subscriptionStatus='Cancelled';
        this.empoyerdetailsService.updateEmployeeDetails(this.employerDetails).subscribe((data: any) =>{
        this.employerDetails = data;
        });
      }
    });
  }

  postErCodeToADP(msg:any){
    console.log("Inside postErCodeToADP");
    this.employerdialogService.openDialog(msg).afterClosed().subscribe(res=>{
      console.log(res)
      if(res){
        this.refreshApiRequest.clientId = this.employerDetails.clientDetails[0].clientId
        this.refreshApiRequest.ewsErCode = this.employerDetails.clientDetails[0].employerCode
        this.refreshApiRequest.workflowType='PostErCode'
        this.refreshApiRequest.processingStatus='Pending'
        this.empoyerdetailsService.updateScheduleDetails(this.refreshApiRequest).subscribe((data: any) =>{
            console.log(data)
            if(data.status=="true"){
              alert("PostErCode to ADP successfully")
            }else{
              alert("PostErCode to ADP unsuccessfull")
            }
          });
        }
  });
 }

  onReset(){
    console.log("Inside on reset");
    this.employerdialogService.openResetDialog().afterClosed().subscribe(res => {
      console.log(res)
      if(res){
        console.log("Inside if block "+ res)
        this.refreshApiRequest.clientId = this.employerDetails.clientDetails[0].clientId
        this.refreshApiRequest.ewsErCode = this.employerDetails.clientDetails[0].employerCode
        this.refreshApiRequest.workflowType=res
        this.refreshApiRequest.processingStatus='Pending'
        this.empoyerdetailsService.updateScheduleDetails(this.refreshApiRequest).subscribe((data: any) =>{
            console.log(data)
            if(data.status=="true"){
              alert("Reset client with "+res+" successfully.")
            }else{
              alert("Reset client with "+res+" successfully.")
            }
          });
      }
    });
  }

  onOptionsSelectedReviewSubStatus(value:string){
    console.log("the selected value is " + value);
    if(this.employerDetails.clientDetails[0].reviewSubscriptionStatus != value){
      console.log("the selected value is different " + value);
      this.employerDetails.clientDetails[0].reviewSubscriptionStatus=value;
      this.empoyerdetailsService.updateEmployeeDetails(this.employerDetails).subscribe((data: any) =>{
      this.employerDetails = data;
      alert("Review Subscription Status changed successfully.")
      });
    }
}
    
}
