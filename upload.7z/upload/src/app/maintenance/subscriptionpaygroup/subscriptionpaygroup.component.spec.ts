import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscriptionpaygroupComponent } from './subscriptionpaygroup.component';

describe('SubscriptionpaygroupComponent', () => {
  let component: SubscriptionpaygroupComponent;
  let fixture: ComponentFixture<SubscriptionpaygroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubscriptionpaygroupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscriptionpaygroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
