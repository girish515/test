import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscriptionpaygroup',
  templateUrl: './subscriptionpaygroup.component.html',
  styleUrls: ['./subscriptionpaygroup.component.css']
})
export class SubscriptionpaygroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
