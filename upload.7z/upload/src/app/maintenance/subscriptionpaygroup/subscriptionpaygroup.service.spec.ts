import { TestBed } from '@angular/core/testing';

import { SubscriptionpaygroupService } from './subscriptionpaygroup.service';

describe('SubscriptionpaygroupService', () => {
  let service: SubscriptionpaygroupService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SubscriptionpaygroupService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
