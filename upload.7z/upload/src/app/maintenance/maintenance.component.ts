import { CommentsService } from './comments/comments.service';
import { Comment } from './comments/comment';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { ApiService } from '../api.service';



@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.css']
})

export class MaintenanceComponent implements OnInit {

  @ViewChild('tabs') tabs: any;
  formGroup: FormGroup;

  activeTab = 'search';
  showTab = false;
  clientId :any;
  employerCode:any;

  constructor(private fb: FormBuilder, private apiService: ApiService) {
    //constructor(private fb: FormBuilder , private apiService: ApiService, private commentsService: CommentsService) {
    this.formGroup = fb.group({
      employerCodeCtrl: [''],
      orgIdCtrl: [],
      payrollRegionCtrl: [],
      payrollGroupCtrl: []
    });
  }

  ngOnInit(): void {
    localStorage.setItem('login', 'true')
  }



  details: Comment[] = [];

  onSubmit() {
    this.clientId = this.formGroup.controls['orgIdCtrl'].value;
    this.employerCode = this.formGroup.controls['employerCodeCtrl'].value;
    console.log("clientId1 : " +this.clientId);
    console.log("this.employerCode1 : " +this.employerCode);
    console.log("Form value : " + JSON.stringify(this.formGroup.value));
    this.showTab = true;
    this.activeTab = 'employer_details';
    //    this.details = this.commentsService.getComments(this.formGroup.value.orgIdCtrl);
  }

  onClear() {
    this.formGroup.reset();
    this.showTab = false;
  }


  setTab(activeTab: any) {
    this.activeTab = activeTab;
  }
}


