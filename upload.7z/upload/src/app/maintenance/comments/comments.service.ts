import { Injectable } from '@angular/core';
import { Comment, CommentRequest, CommentResponse } from './comment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class CommentsService {

  private endpoint = "http://localhost:8090/comments-api/v1/comment/";
  //private endpoint = "http://localhost:8080/comments-api/v1/comment/";

  headers = {
    "RequestId": "1"
  };

  constructor(private httpClient: HttpClient) { }

  public getComments(clientId: string) {
    var cd:Comment[] = [];
    var message:Comment[] = []; 
    var xhr = new XMLHttpRequest();
    xhr.open('GET', this.endpoint + clientId, true);
    //xhr.setRequestHeader('requestId', '1');
    //xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
    xhr.send(null);
    xhr.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var res:CommentResponse = JSON.parse(this.response);
        message = res.commentsDetails;
        message.forEach(element => { 
          cd.push(element);
        });
      }
    };
    return cd;
  }

  postComments(){
    console.log("postcomments invoked");
    let body = {
        comments :'TestComment',
        createdBy : 'admin'
    }
    return this.httpClient.post("http://localhost:8080/api/config/comment",body)

/*public postComment(clientId: any) {
    var xhr = new XMLHttpRequest();
    var comment: Comment = <Comment>{
      comments: <string>text
    }
    var req = new CommentRequest(comment, clientId);
    xhr.open("POST", this.endpoint, true);

    //Send the proper header information along with the request
    xhr.setRequestHeader("requestId", "2");
    xhr.setRequestHeader("Content-type", "application/json")

    xhr.onreadystatechange = function() { // Call a function when the state changes.
      if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
        // Request finished. Do processing here.
      }
    }
    xhr.send(JSON.stringify(comment));
    // xhr.send(new Int8Array());
    // xhr.send(document);
  */  }

}
