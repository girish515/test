export interface Comment {
    commentSeqId?: number;
    accountId?: string;
    comments: string;
    createdOn: Date;
    createdBy?: string;
    updatedOn?: Date;
    updatedBy?: string;
  }

export interface CommentResponse {
  commentsDetails: Comment[];
}

export class CommentRequest {
  commentDetails: Comment;
  clientId: string;

  constructor(comment: Comment, clientId: string) {
    this.commentDetails = comment;
    this.clientId = clientId;
  }
}