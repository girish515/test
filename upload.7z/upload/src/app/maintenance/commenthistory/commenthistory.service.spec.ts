import { TestBed } from '@angular/core/testing';

import { CommenthistoryService } from './commenthistory.service';

describe('CommenthistoryService', () => {
  let service: CommenthistoryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommenthistoryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
