import { Component, OnInit } from '@angular/core';
import { CommenthistoryService } from './commenthistory.service';

@Component({
  selector: 'app-commenthistory',
  templateUrl: './commenthistory.component.html',
  styleUrls: ['./commenthistory.component.css']
})
export class CommenthistoryComponent implements OnInit {

  details: Comment[] = [];

  constructor(private commenthistoryService:CommenthistoryService) { }

  ngOnInit(): void {
  }

  onCommentSubmit() {
    var comment = <HTMLInputElement>document.getElementById('commentbox')!;
    var text = comment.value;
    //this.commentsService.postComment(text, this.formGroup.value.orgIdCtrl);
    window.location.reload();

    //    console.log("Form value : " +JSON.stringify(this.formGroup.value));
    console.log("comment submit : ");
    this.commenthistoryService.postComments().subscribe((data: any) => {
      console.log("Data : " + JSON.stringify(data));
    });
  }

}
