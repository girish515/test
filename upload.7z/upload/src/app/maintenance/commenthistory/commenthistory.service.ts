import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommenthistoryService {

  constructor(private httpClient: HttpClient) { }

  postComments(){
    let body = { 
        commentData :'TestComment',
        user : 'admin'
    }
    return this.httpClient.post("http://localhost:8080/api/config/comment",body)
  }

}
