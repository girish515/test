import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  constructor(private httpClient: HttpClient) { }

  fetchNotificationsData(employerCode:any,clientId:any){
    let notificationId:any;
    if(clientId != null && clientId != ''){
      notificationId = clientId;
    } else {
      notificationId = employerCode;
    }
    console.log("notificationId : " +notificationId);
//    return this.httpClient.get("http://localhost:8098/notifications-api/v1/" +notificationId)
    return   this.httpClient.get("./assets/data/notification.json");
  }
}
