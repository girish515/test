import { Component, Input,Output, OnInit,ViewChild ,AfterViewInit , EventEmitter} from '@angular/core';
import { NotificationsService } from './notifications.service';

import {MatTableDataSource, MatTable} from '@angular/material/table';
import { MatSort ,Sort} from '@angular/material/sort';

import {animate, state, style, transition, trigger} from '@angular/animations';

import { SelectionModel } from '@angular/cdk/collections';
import { TitleCasePipe } from '@angular/common';
import { MatPaginator, PageEvent } from '@angular/material/paginator';


@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit , AfterViewInit{

  @Input() clientId :any;
  @Input() employerCode:any;
  employerDetails: any;
  payrollNotfInfo: any;
  payrollNotfInfoFilter: any;
  yearArray = new Array();
  isDataLoaded = false;
  notificationAPIResponse: any

  results:any = [];
  selectedResult:any = [];


  @Output() selectedItem: EventEmitter<any> = new EventEmitter();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatPaginator, {static: true}) set matPaginator(paginator: MatPaginator) {
    this.dataSource.paginator = paginator;
}
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  displayedColumns: string[] = ['payrollRegionCode', 'payrollGroupCode', 'payrollRunType', 'Run Number','Week Number','payrollPayDate','Notification Date','processed Date','Processed'];
  dataSource = new MatTableDataSource();
  data: any;
  selection = new SelectionModel(true, []);
  pagesize = 2;
  resultsLength = 0;
  tableData = [];
 // headElements = ['Region', 'Group', 'Run Type', 'Run Number','Week Number','Pay Date','Notification Date','processed Date','Processed'];

  constructor(private notificationsService:NotificationsService ) { }




  ngOnInit(): void {
    console.log("clientId : " +this.clientId);
    console.log("employerCode : " +this.employerCode);
    this.fetchNotificationData();
  }

  ngAfterViewInit() {
/*    this.refresh();

    this.sort.sortChange.subscribe((sort: Sort) => {
      console.log('sortChange', this.sort.active);
      this.paginator.pageIndex = 0;
      this.refresh();
    });

    this.paginator.page.subscribe((page: PageEvent) => {
      console.log('paginator ', page);
      this.refresh();
    }); */
  setTimeout(() => {
  this.dataSource.paginator = this.paginator;
  });
  }

  fetchNotificationData() {
    //   this.payrollNotfInfo = this.notificationData1['response '][0].payrollNotfInfo;
    console.log("Invoking fetch notification API");
    this.notificationsService.fetchNotificationsData(this.employerCode, this.clientId).subscribe(response => {
      this.notificationAPIResponse = response;
      this.yearArray = this.notificationAPIResponse['response '][0].payrollYear;
      this.payrollNotfInfo = this.notificationAPIResponse['response '][0].payrollNotfInfo;
/*      this.results =  this.payrollNotfInfo;
      this.resultsLength = this.payrollNotfInfo .length;
      this.dataSource = new MatTableDataSource(this.payrollNotfInfo );
 //     setTimeout(() => {
        this.dataSource.paginator = this.paginator;
//      }); */
    });
  }

  decideDisplay(payrollPayDate:any , year:any){
    if(payrollPayDate.includes(year)){
      return true;
    } else {
      return false;
    }
  }

  /*
  tableDataDisplay(){
    this.payrollNotfInfo.array.forEach(item => {
      this.payrollNotfInfoFilter.add(this.decideDisplay(item.payrollPayDate, ''));
    });
    
  } */
/*
  getData( event: any) {

    this.selectedResult = this.results.slice(event.pageIndex * event.pageSize, event.pageIndex * event.pageSize + event.pageSize);
    return event;
  } */

  filterData(year:any){
console.log("test");
this.dataSource = new MatTableDataSource();
//this.fetchNotificationData();
let filterNotificstion:any [] = new Array();

for(var i = 0 ; i< this.payrollNotfInfo.length ; i++){

  if(this.payrollNotfInfo[i].payrollPayDate.includes(year)){
    filterNotificstion.push(this.payrollNotfInfo[i]);
  }
}


this.results =  filterNotificstion;
this.resultsLength = filterNotificstion .length;
this.dataSource = new MatTableDataSource(filterNotificstion);
//setTimeout(() => {
  this.dataSource.paginator = this.paginator;
//});
this.isDataLoaded = true;
  }
/*
  refresh() {
    this.notificationsService.fetchNotificationsData(this.employerCode, this.clientId).subscribe((result: any) => {
      this.tableData = result;
      this.resultsLength = result.length;
      this.dataSource = new MatTableDataSource(result);
      setTimeout(() => {
        this.dataSource.paginator = this.paginator;
      });
    });
  } */

  tableHeaderDisplay(value:any) {
    let data = '';
    if (value.includes('payrollRegionCode')) {
      data = 'Region';
    } else {
      data = value;
    }
    return data;
  }

}

