import { Component, Input, OnInit, Output ,EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import {AppComponent} from '../app.component'


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() isLogin:boolean = true;
  @Output() isLogout:EventEmitter<any> = new EventEmitter();

  constructor(private appComponent:AppComponent,
    private router:Router) { }

  ngOnInit(): void {
  }

  logout(){
    this.isLogout.emit(false);
    this.goToPage('login');
  }

  goToPage(value:any){
    this.router.navigate(['/' +value])
  }
}
