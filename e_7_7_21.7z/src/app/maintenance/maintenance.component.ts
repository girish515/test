import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.css']
})
export class MaintenanceComponent implements OnInit {

  @ViewChild('tabs') tabs:any; 
  formGroup: FormGroup;
  
  activeTab = 'search';
  showTab = false;
  constructor(private fb: FormBuilder) {
    this.formGroup = fb.group({
      employerCodeCtrl:['', Validators.required],
      orgIdCtrl:[],
      payrollRegionCtrl:[],
      payrollGroupCtrl:[]
    });
  }

  ngOnInit(): void {
    localStorage.setItem('login' , 'true')
  }

  onSubmit() {
    console.log("Form value : " +JSON.stringify(this.formGroup.value));
    this.showTab = true;
    this.activeTab = 'employer_details';
  }
  onClear() {
 this.formGroup.reset();
 this.showTab = false;
  }


  setTab(activeTab:any){
    this.activeTab = activeTab;
  }
}
