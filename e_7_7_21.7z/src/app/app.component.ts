import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'equifax';
  isLogin = false;
  currentUser: any;
  constructor( private activatedRoute:ActivatedRoute,
    private router: Router,
) {
}

ngOnInit(): void {
  this.activatedRoute.queryParams.subscribe(params => {
    let isLogin = params['login'];
    if(isLogin === true || localStorage.getItem('login') === 'true'){
      this.isLogin = true;
      localStorage.setItem('login','true');
    } else {

    }
  });

}

logout(e:any) {
this.isLogin = e;
localStorage.setItem('login','false');
}

}
