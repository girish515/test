import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loading = false;
  submitted = false;

  constructor(private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private appComponent:AppComponent) { }

  ngOnInit(): void {
/*
    this.activatedRoute.queryParams.subscribe(params => {
      let isLogin = params['login'];

      if(isLogin === true){
        localStorage.setItem('login','true');
        this.login();
      } else {
        localStorage.setItem('login','false');
        this.appComponent.isLogin = false;
      }
    }); */
    localStorage.setItem('login' , 'false')
  }
  

  login(){
    localStorage.setItem('login','true');
    this.appComponent.isLogin = true;
    this.goToPage('home');
  }

  goToPage(value:any){
    this.router.navigate(['/'+value]);
  }

}
