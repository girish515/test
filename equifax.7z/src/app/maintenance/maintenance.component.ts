import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.css']
})
export class MaintenanceComponent implements OnInit {

  formGroup: FormGroup;

  constructor(private fb: FormBuilder) {
    this.formGroup = fb.group({
      employerCodeCtrl:[],
      orgIdCtrl:[],
      payrollRegionCtrl:[],
      payrollGroupCtrl:[]
    });
  }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log("Form value : " +JSON.stringify(this.formGroup.value));

  }
  onClear() {
this.formGroup.reset();
  }
}
